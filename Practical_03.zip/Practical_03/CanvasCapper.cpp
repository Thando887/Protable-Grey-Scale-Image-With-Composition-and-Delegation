#include "CanvasCapper.h"

void CanvasCapper::applyRangeRules(Canvas2D& objCanvas, int intMin, int intMax)
{
    for(int r = 0; r < objCanvas.getRows(); r++)
    {
        for(int c = 0; c < objCanvas.getCols(); c++)
        {
            enforceRange(intMin, Canvas2D::MIN_INTENSITY, Canvas2D::MAX_INTENSITY);
            enforceRange(intMax, Canvas2D::MIN_INTENSITY, Canvas2D::MAX_INTENSITY);
            enforceRange(objCanvas.getPixel(r, c), intMin, intMax);
        }
    }
}

void CanvasCapper::enforceRange(int intValue, int intMin, int intMax) const
{
   if(intValue < intMin)
   {
       intValue = intMin;
   }
   if(intValue > intMax)
   {
       intValue = intMax;
   }
}
