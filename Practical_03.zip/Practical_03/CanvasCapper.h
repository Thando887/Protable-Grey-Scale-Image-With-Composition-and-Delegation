#ifndef CANVASCAPPER_H
#define CANVASCAPPER_H

#include "Canvas2D.h"

class Canvas2D;

class CanvasCapper
{
    public:
        void applyRangeRules(Canvas2D& objCanvas, int intMin, int intMax);
    private:
        void enforceRange(int intValue, int intMin, int intMax) const;
};

#endif // CANVASCAPPER_H
